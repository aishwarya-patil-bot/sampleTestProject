package com.abnamro.apps.referenceandroid.Robot;

import com.abnamro.apps.referenceandroid.R;

import android.widget.TextView;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isClickable;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withContentDescription;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withParent;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.core.AllOf.allOf;

public class HomeRobot {

    //Verify Hello World is displayed on home Screen
    public void homeScreenVerification() {
        onView(allOf(instanceOf(TextView.class), withParent(withId(R.id.fragment))))
                .check(matches(isDisplayed()))
                .check(matches(withText("Hello World!")));
    }

    //Verify toolbar is displayed on home Screen
    public void toolBarVerification() {
        onView(allOf(instanceOf(TextView.class), withParent(withId(R.id.toolbar))))
                .check(matches(isDisplayed()))
                .check(matches(withText("ReferenceAndroid")));

    }

    //Verify More Options is displayed on Home Screen
    public void menuBarVerification() {
        onView(withContentDescription("More options"))
                .check(matches(isDisplayed()));
    }

    //Click on More options on menu bar
    public void clickOnMenuOptions() {
        onView(withContentDescription("More options"))
                .perform(click());
    }

    //Verify settings bar
    public void settingsMenuBarVerification() {
        onView(withId(R.id.title)).check(matches(isDisplayed()))
                .check(matches(withText(R.string.action_settings)));
    }

    //Verify mail button is displayed on home screen
    public void mailButtonVerification() {
        onView(withId(R.id.fab)).check(matches(isDisplayed()))
                .check(matches(isClickable()));
    }

    //Verify snack bar
    public void snackBarVerification() {
        onView(withId(R.id.fab)).perform(click());

        onView(withId(R.id.snackbar_text))
                .check(matches(isDisplayed()))
                .check(matches(withText("Replace with your own action")));
    }

    //Verify status bar is displayed on home Screen
    public void statusBarVerification() {
        onView(withId(android.R.id.statusBarBackground))
                .check(matches(isDisplayed()));
    }

    //Verify navigation bar is displayed on home Screen
    public void navBarVerification() {
        onView(withId(android.R.id.navigationBarBackground))
                .check(matches(isDisplayed()));
    }
}
