package com.abnamro.apps.referenceandroid.test;

import android.content.pm.ActivityInfo;

import androidx.test.ext.junit.runners.AndroidJUnit4;

import android.app.Activity;
import android.content.Intent;

import androidx.test.rule.ActivityTestRule;

import com.abnamro.apps.referenceandroid.MainActivity;
import com.abnamro.apps.referenceandroid.com.*;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)

public class testHomeScreen extends commonFunctions {

    @Rule
    public ActivityTestRule<MainActivity> mActivityTestRule = new ActivityTestRule<>(MainActivity.class);
    private Activity activity;

    //verification of Home Screen objects
    @Test
    public void testHomeScreen() {

        mActivityTestRule.getActivity().setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        mActivityTestRule.launchActivity(new Intent());
        activity = mActivityTestRule.getActivity();

        homeScreenVerification();
        toolBarVerification();
        menuBarVerification();
        statusBarVerification();
        navBarVerification();
    }

    //verification of sub menu
    @Test
    public void testMenuBar() {
        mActivityTestRule.launchActivity(new Intent());
        activity = mActivityTestRule.getActivity();
        menuBarVerification();
    }

    //verification of mail button and snack bar
    @Test
    public void testMailFuntionality() {
        mActivityTestRule.launchActivity(new Intent());
        activity = mActivityTestRule.getActivity();
        mailButtonVerification();
        snackBarVerification();
        mActivityTestRule.finishActivity();
    }

}

