package com.abnamro.apps.referenceandroid.test;

import android.content.pm.ActivityInfo;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import android.app.Activity;
import android.content.Intent;
import androidx.test.rule.ActivityTestRule;
import com.abnamro.apps.referenceandroid.MainActivity;
import com.abnamro.apps.referenceandroid.com.*;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)

public class testHomeScreen extends commonFunctions {

     @Rule
    public ActivityTestRule<MainActivity> mActivityTestRule = new ActivityTestRule<>(MainActivity.class);
    private Activity activity;

     @Test
    public void test1() {

        //setting device in portrait mode
        mActivityTestRule.getActivity().setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        //Launch activity
        mActivityTestRule.launchActivity(new Intent());
        activity = mActivityTestRule.getActivity();

        //verification of Home Screen objects
            homeScreenVerification();
            toolBarVerification();
            menuBarVerification();
            statusBarVerification();
            navBarVerification();


        //verification of sub menu
        menuBarVerification();

        //verification of mail button and snack bar
            mailButtonVerification();
            snackBarVerification();

            mActivityTestRule.finishActivity();
        }

    }

