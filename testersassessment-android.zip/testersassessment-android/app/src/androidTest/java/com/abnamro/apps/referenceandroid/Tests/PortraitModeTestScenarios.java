package com.abnamro.apps.referenceandroid.Tests;

import android.content.pm.ActivityInfo;

import androidx.test.ext.junit.runners.AndroidJUnit4;

import android.content.Intent;

import androidx.test.rule.ActivityTestRule;

import com.abnamro.apps.referenceandroid.MainActivity;
import com.abnamro.apps.referenceandroid.Robot.HomeRobot;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

/**
 * Instrumented test, which will execute on an Android device.
 * This class contains all test cases to execute in portrait mode
 */
@RunWith(AndroidJUnit4.class)

public class PortraitModeTestScenarios extends HomeRobot {

    @Rule
    public ActivityTestRule<MainActivity> referenceAndroidActivityTestRule = new ActivityTestRule<>(MainActivity.class);

    /**
     * This method will execute before every test and set the screen mode to portrait
     */
    @Before
    public void setUp() {
        referenceAndroidActivityTestRule.launchActivity(new Intent());
        referenceAndroidActivityTestRule.getActivity().setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    }

    /**
     * This method will execute after every test
     */
    @After
    public void tearDown() {
        referenceAndroidActivityTestRule.finishActivity();
    }

    /**
     * This method will verify the objects in the Home Screen
     */
    @Test
    public void testHomeScreen() {
        homeScreenVerification();
        toolBarVerification();
        menuBarVerification();
        statusBarVerification();
        navBarVerification();
    }

    /**
     * This method will verify the objects in the menu bar
     */
    @Test
    public void testMenuBar() {
        menuBarVerification();
        clickOnMenuOptions();
        settingsMenuBarVerification();
    }

    /**
     * This method will verify that the mail button is clickable and the snack bar
     */
    @Test
    public void testMailFunctionality() {
        mailButtonVerification();
        snackBarVerification();
    }
}
